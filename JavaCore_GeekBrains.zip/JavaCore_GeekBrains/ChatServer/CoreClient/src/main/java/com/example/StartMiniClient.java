package com.example;

public class StartMiniClient {
    public static void main(String[] args) {

       new Client();

    }
}