package naumDeveloper.javaCore2.unit_2;

public class MyArraySizeException extends Exception {
    public MyArraySizeException(String mes) {
        super(mes);
    }
}
