package naumDeveloper.javaCore2.unit_1;

public abstract class AbstractMaster {
    protected String nemi;
    protected int run;
    protected int jump;

}
