package naumDeveloper.javaCore2.unit_6.Client;

public class ClientMain {
    public static void main(String[] args) {

       new Client();

    }
}