package naumDeveloper.javaCore2.unitLinkList;

public class Main {

    public static void main(String[] args) {

        DuobleLingList next = new DuobleLingList();
        next.addEtana("1");
        next.addEtana("2");
        next.addEtana("3");


        System.out.println(next);
    }
    
}
