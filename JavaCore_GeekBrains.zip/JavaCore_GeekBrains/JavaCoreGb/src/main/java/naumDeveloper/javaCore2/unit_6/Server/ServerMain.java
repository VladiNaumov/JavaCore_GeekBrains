package naumDeveloper.javaCore2.unit_6.Server;

import java.io.IOException;

public class ServerMain {
    public static void main(String[] args) throws IOException {

        new Server();
    }
}