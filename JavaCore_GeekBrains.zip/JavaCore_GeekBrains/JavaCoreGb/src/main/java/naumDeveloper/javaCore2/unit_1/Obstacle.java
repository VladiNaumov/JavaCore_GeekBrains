package naumDeveloper.javaCore2.unit_1;

public interface Obstacle {
    int getHeingth();
    int getLength();

}
