package naumDeveloper.javaCore3.unit_1.generic.document;

import java.io.File;

public class PdfDocument implements IDocument<File>{


    @Override
    public File getHeader() {
        return null;
    }

    @Override
    public File getContent() {
        return null;
    }
}
