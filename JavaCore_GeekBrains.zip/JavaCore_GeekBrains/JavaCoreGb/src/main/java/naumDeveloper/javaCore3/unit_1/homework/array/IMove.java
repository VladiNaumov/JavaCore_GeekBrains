package naumDeveloper.javaCore3.unit_1.homework.array;

public interface IMove<T>{
    T myMove(int[] str);
}
