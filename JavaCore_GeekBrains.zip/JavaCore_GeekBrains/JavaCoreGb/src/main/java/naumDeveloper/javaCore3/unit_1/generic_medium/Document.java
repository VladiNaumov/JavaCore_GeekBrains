package naumDeveloper.javaCore3.unit_1.generic_medium;

public interface Document<T> {
    T getHeader();
    T getContent();

}
