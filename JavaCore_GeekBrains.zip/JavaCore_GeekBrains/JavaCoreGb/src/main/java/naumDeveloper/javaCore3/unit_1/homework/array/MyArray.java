package naumDeveloper.javaCore3.unit_1.homework.array;


import java.util.ArrayList;

public class MyArray implements IArray<ArrayList<Integer>> {
    @Override
    public ArrayList setArrayList(int[] array) {
        return  new ArrayList();
    }
}
