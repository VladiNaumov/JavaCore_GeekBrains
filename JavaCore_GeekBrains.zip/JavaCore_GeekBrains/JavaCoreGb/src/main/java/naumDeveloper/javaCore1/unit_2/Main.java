package naumDeveloper.javaCore1.unit_2;

public class Main {

    public static void main(String[] args) {
        ArrayApp myapps = new ArrayApp();

        // myapps.myArrayZeroOne();
        // myapps.myArrayMinimumSix();
        //  myapps.myArrayСreature();
        // myapps.arrayMinMax();
        myapps.twoArray();



    }
}
