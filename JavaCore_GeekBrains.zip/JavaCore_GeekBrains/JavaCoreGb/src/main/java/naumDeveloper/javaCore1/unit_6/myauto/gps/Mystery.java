package naumDeveloper.javaCore1.unit_6.myauto.gps;

public class Mystery implements NavigationSystem {
    public boolean createRoute() {

        System.out.println("Route was created by Mystery T1000");

        return true;
    }
}
