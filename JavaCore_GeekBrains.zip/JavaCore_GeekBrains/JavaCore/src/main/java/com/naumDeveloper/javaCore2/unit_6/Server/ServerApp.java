package com.naumDeveloper.javaCore2.unit_6.Server;

public class ServerApp {
    public static void main(String[] args) {
        new Server(8189);
    }
}
