package com.naumDeveloper.javaCore2.unit_8.DoubleLinkinList;

public class Main {

    public static void main(String[] args) {
        DuobleLingList my = new DuobleLingList();
        my.add("111");
        my.add("222");
        my.add("333");

        System.out.println(my);
    }
    
}
