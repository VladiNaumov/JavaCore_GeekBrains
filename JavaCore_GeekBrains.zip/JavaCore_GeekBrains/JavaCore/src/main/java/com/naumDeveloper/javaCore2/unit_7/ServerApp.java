package com.naumDeveloper.javaCore2.unit_7;

public class ServerApp {
    public static void main(String[] args) {
        new Server(8189);
    }
}
