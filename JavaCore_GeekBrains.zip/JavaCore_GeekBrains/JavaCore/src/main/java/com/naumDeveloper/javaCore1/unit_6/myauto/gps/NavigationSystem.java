package com.naumDeveloper.javaCore1.unit_6.myauto.gps;

public interface NavigationSystem {
    boolean createRoute();
}
