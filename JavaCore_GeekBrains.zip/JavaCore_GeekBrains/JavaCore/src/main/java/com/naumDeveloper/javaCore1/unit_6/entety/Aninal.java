package com.naumDeveloper.javaCore1.unit_6.entety;

public abstract class Aninal {

   protected String name;



    abstract void runing(int runing);

    abstract void jumping(double jumping);

    abstract void swiming(int swiming);

}
