package com.naumDeveloper.javaCore1.unit_6.myauto.audisystem;

public interface AudioSystem {

    void playCD();
    void playRadio();

}
