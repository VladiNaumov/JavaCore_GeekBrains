package com.naumDeveloper.javaCore1.unit_6.myauto.gps;

public class Garmin implements NavigationSystem {

    public boolean createRoute() {

        System.out.println("Route was created by Garmin 4000");

        return true;
    }


}
