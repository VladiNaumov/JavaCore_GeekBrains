package com.naumDeveloper.javaCore1.unit_6.myauto.gps;

public class Navitel implements NavigationSystem {
    public boolean createRoute() {

        System.out.println("Route was created by Navotel R777");

        return true;
    }
}
