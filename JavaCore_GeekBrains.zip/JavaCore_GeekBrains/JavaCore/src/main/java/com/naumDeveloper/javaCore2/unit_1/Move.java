package com.naumDeveloper.javaCore2.unit_1;

public interface Move {

      void jumpRun (Obstacle[] masterJumpRuns);

}
