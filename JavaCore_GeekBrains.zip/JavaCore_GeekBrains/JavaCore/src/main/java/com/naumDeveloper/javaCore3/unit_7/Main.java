package com.naumDeveloper.javaCore3.unit_7;

public class Main {
}
