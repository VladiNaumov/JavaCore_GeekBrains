package com.naumDeveloper.javaCore2.unit_5;

public class StartApp {

    public static void main(String[] args) {
        Threeds my = new Threeds();
      //  my.calc();
        my.calcJoin();
    }
}
