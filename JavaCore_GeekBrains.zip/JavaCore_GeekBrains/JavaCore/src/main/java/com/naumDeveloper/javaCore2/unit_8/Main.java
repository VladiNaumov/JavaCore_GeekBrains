package com.naumDeveloper.javaCore2.unit_8;

public class Main {
}
