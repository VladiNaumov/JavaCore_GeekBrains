package com.naumDeveloper.javaCore3.unit_1.homework.array;

public interface IArray<T> {

    T setArrayList(int[]array);

}
