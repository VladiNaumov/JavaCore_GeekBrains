package com.naumDeveloper.javaCore3.unit_5;

public class Main {
}
