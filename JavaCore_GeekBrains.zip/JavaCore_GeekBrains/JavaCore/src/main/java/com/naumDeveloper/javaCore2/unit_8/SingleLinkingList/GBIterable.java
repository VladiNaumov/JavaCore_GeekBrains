package com.naumDeveloper.javaCore2.unit_8.SingleLinkingList;

public interface GBIterable {
    GBIterator iterator();
}
