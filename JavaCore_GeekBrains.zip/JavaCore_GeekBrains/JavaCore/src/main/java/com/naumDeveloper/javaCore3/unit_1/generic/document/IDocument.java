package com.naumDeveloper.javaCore3.unit_1.generic.document;

public interface IDocument <T>{
    T getHeader();
    T getContent();


}
