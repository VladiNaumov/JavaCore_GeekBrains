package org.example.more.callback;

@FunctionalInterface
public interface Action {
    void doIt();

}
